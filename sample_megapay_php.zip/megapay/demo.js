$(document).ready(function () {
    $('ul.tabs li').click(function () {
        var tab_id = $(this).attr('data-tab');

        $('ul.tabs li').removeClass('current');
        $('.tab-content').removeClass('current');

        $(this).addClass('current');
        $("#" + tab_id).addClass('current');
    })
})

var path = location.href;
	path = path.replace('/test.php', '');

window.addEventListener('message', function (e) {
    console.log('Sample Listener');
    if (e.data.closeLayer == 'close') {
        window.top.closeLayer();
    }
});

// Function Payment
function payment() {
    var amount = $('#amount').val();

    // Check Amount
    if (amount == '') {
        alert('Please Enter Amount!');
        $('#amount').focus();
        return false;
    }

    $.ajax({
        url: path + '/process.php',
        type: 'post',
        dataType: 'json',
        data: {amount: amount, type: 1},
        success: function (res) {
            if (res.success) {
                var domain = res.domain;
                paymentForm = document.getElementById('megapayForm');

                paymentForm.elements["timeStamp"].value = res.timeStamp;
                paymentForm.elements['invoiceNo'].value = res.invoiceNo;
                paymentForm.elements['merTrxId'].value = res.merTrxId;
                paymentForm.elements['merId'].value = res.merId;
                paymentForm.elements["merchantToken"].value = res.token;

                openPayment(1, domain);
            } else {
                alert(res.mes);
            }
        },
        error: function () {
            alert('Có lỗi trong quá trình xử lý!');
        }
    });
}

// Function Check Transaction
function status() {
    var merId = $('#merId').val();
    var merTrxId = $('#merTrxId').val();

    // Check Merchant ID
    if (merId == '') {
        alert('Please Enter Merchant ID!');
        $('#merId').focus();
        return false;
    }

    // Check Merchant Transaction ID
    if (merTrxId == '') {
        alert('Please Enter Merchant Transaction ID!');
        $('#merTrxId').focus();
        return false;
    }

    $.ajax({
        url: path + '/process.php',
        type: 'post',
        dataType: 'json',
        data: {type: 2, merId: merId, merTrxId: merTrxId},
        success: function (res) {
            if (res.success) {
                var examineForm = document.getElementById('examineForm');
                examineForm.elements["timeStamp"].value = res.timeStamp;
                examineForm.elements["merchantToken"].value = res.token;

                examineForm.submit();
            } else {
                alert(res.mes);
            }
        },
        error: function () {
            alert('Có lỗi trong quá trình xử lý!');
        }
    });
}

// Function Refund
function refund() {
    var merId = $('#merIdCancel').val();
//    var merTrxId = $('#merTrxId').val();
    var trxId = $('#trxIdCancel').val();
    var amount = $('#amountCancel').val();

    // Check Merchant ID
    if (merId == '') {
        alert('Please Enter Merchant ID!');
        $('#merIdCancel').focus();
        return false;
    }

   

    // Check Trx ID
    if (trxId == '') {
        alert('Please Enter Trx ID!');
        $('#trxIdCancel').focus();
        return false;
    }

    // Check Amount
    if (amount == '') {
        alert('Please Enter Amount!');
        $('#amountCancel').focus();
        return false;
    }

    $.ajax({
        url: path + '/process.php',
        type: 'post',
        dataType: 'json',
        data: {type: 3, merId: merId, trxId: trxId, amount: amount},
        success: function (res) {
            if (res.success) {
                console.log(res.token);
                var cancelForm = document.getElementById('cancelForm');
                cancelForm.elements["merTrxId"].value = res.merTrxId;

                cancelForm.elements["timeStamp"].value = res.timeStamp;
                cancelForm.elements["merchantToken"].value = res.token;

                cancelForm.submit();
            } else {
                alert(res.mes);
            }
        },
        error: function () {
            alert('Có lỗi trong quá trình xử lý!');
        }
    });
}