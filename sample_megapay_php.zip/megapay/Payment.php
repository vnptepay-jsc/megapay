<?php

class Payment
{
    // Check Token Response
    const MER_ID = 'EPAY000001';
    const ENCODE_KEY = 'rf8whwaejNhJiQG2bsFubSzccfRc/iRYyGUn6SPmT6y/L7A2XABbu9y4GvCoSTOTpvJykFi6b1G0crU8et2O0Q==';
	

    public function checkToken($data)
    {
        $timeStamp = $data['timeStamp'];
        $merTrxId = $data['merTrxId'];
        $trxId = $data['trxId'];
        $amount = $data['amount'];

        $str = $timeStamp . $merTrxId . $trxId . self::MER_ID . $amount . self::ENCODE_KEY;

        $token = hash('sha256', $str);

        $tokenResponse = $data['merchantToken'];

        if ($token != $tokenResponse) {
            return false;
        }

        return true;
    }

    public function randomData(){
        // buyerPhone
        $buyerPhone = '0989'.self::randomString(6,'0123456789');

        // buyerAddr
        $buyerAddr = self::randomString(10,'ABCDEFGHIJKLMNOPQRSTUVWXYZ');

        // buyerCity
        $aryPro = array('Ha Giang', 'Cao Bang', 'Bac Kan', 'Lang Son', 'Tuyen Quang', 'Thai Nguyen',
            'Phu Tho', 'Bac Giang', 'Quang Ninh','Bac Ninh', 'Ha Noi', 'TP HCM', 'Ha Nam', 'Ha Tinh',
            'Hai Duong', 'Hau Giang', 'Hoa Binh', 'Hung Yen', 'Khanh Hoa', 'Kien Giang');
        $buyerCity = array_rand($aryPro);

        // receiverFirstNm
        $receiverFirstNm = self::randomString(5,'ABCDEFGHIJKLMNOPQRSTUVWXYZ');

        //receiverLastNm
        $receiverLastNm = self::randomString(5,'ABCDEFGHIJKLMNOPQRSTUVWXYZ');

        //receiverPhone
        $receiverPhone = '0912'.self::randomString(6,'0123456789');

        //receiverAddr
        $receiverAddr = self::randomString(10,'ABCDEFGHIJKLMNOPQRSTUVWXYZ');

        //receiverCity
        $receiverCity = array_rand($aryPro);

        //description
        $description = self::randomString(10,'abcdefghijklmnopqrstuvwxyz');

        //buyerLastNm
        $buyerLastNm = self::randomString(5,'ABCDEFGHIJKLMNOPQRSTUVWXYZ');

        // buyerFirstNm
        $buyerFirstNm = self::randomString(5,'ABCDEFGHIJKLMNOPQRSTUVWXYZ');

        // buyerEmail
        $buyerEmail = self::randomString(6,'abcdefghijklmnopqrstuvwxyz').'@gmail.com';

        $data = array(
            'buyerPhone' => $buyerPhone,
            'buyerAddr' => $buyerAddr,
            'buyerCity' => $buyerCity,
            'receiverFirstNm'=>$receiverFirstNm,
            'receiverLastNm' => $receiverLastNm,
            'receiverPhone' => $receiverPhone,
            'receiverAddr' => $receiverAddr,
            'receiverCity' => $receiverCity,
            'description' => $description,
            'buyerLastNm'=> $buyerLastNm,
            'buyerFirstNm' => $buyerFirstNm,
            'buyerEmail' => $buyerEmail
        );

        return $data;
    }

    public function randomString($length, $chars){
        $size = strlen( $chars );
        $str = '';
        for( $i = 0; $i < $length; $i++ ) {
            $str .= $chars[ rand( 0, $size - 1 ) ];
        }
        return $str;
    }
}

?>