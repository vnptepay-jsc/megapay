<?php
$result = $_POST;
include("Payment.php");
$payment = new Payment();

// Check Token
$check = $payment->checkToken($result);
$error = '';
if (!$check) {
    echo 'Error';
} else {
    echo $result;
}

// Result Example

//$result = array(
//    'accessUrl' => 'http://localhost/megapay/notify',
//    'buyerLastNm' => 'Doe',
//    'trxTm' => '164158',
//    'cardNo' => '970400xxxxxx0018',
//    'vaNumber' => 'null',
//    'matchStatus' => '1',
//    'payType' => 'DC',
//    'currency' => 'VND',
//    'instmntMon' => 'null',
//    'invoiceNo' => 'OrdNo20191164337826',
//    'merchantToken' => '50b5805131cbffcb6a795fd116197b484ae0e6c776cd5eb717db54cb34cf0f20',
//    'amount' => '10000',
//    'goodsNm' => 'T-1000',
//    'merTrxId' => 'EPAYABC1112622019164341LDdcBn',
//    'trxId' => 'EPAYABC111DC201902261641586877',
//    'instmntType' => 'null',
//    'timeStamp' => '1551174221556',
//    'trxDt' => '20190226',
//    'bankId' => 'BIDM',
//    'merId' => 'EPAYABC111',
//    'buyerFirstNm' => 'John',
//    'cardExpireDt' => '0703',
//    'domesticToken' => 'null',
//    'targetUrl' => 'http://localhost/megapay/notify',
//    'status' => 0
//);
?>