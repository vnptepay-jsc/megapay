<?php
    include('Payment.php');
    $payment = new Payment();
    $data = $payment->randomData();
?>
<html>
<head>
    <!--Link To CSS File-->
    <link rel="stylesheet" href="http://sanbox.megapay.vn:2710/pg_was/css/payment/layer/paymentClient.css"
          type="text/css" media="screen">
    <title>Demo Payment</title>
    <meta http-equiv="Content-Type" content="text/html, charset=utf-8">
    <style type="text/css">
        ul.tabs {
            margin: 0px;
            padding: 0px;
            list-style: none;
        }

        ul.tabs li {
            background: none;
            color: #222;
            display: inline-block;
            padding: 10px 15px;
            cursor: pointer;
        }

        ul.tabs li.current {
            background: #ededed;
            color: #222;
        }

        .tab-content {
            display: none;
            background: #ededed;
            padding: 15px;
        }

        .tab-content.current {
            display: inherit;
        }

        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            border: 1px solid #000000;
            text-align: left;
            padding: 8px;
            font-size: 13px;
        }

        form table input[type=text] {
            width: 42%;
        }
    </style>
</head>
<body>
<div style="width: 843px; margin-left: auto; margin-right: auto; margin-top: 4%; text-align: center; border: 1px solid black; padding-top: 1px;">
    <ul class="tabs">
        <li class="tab-link current" data-tab="tab-1">Payment</li>
        <li class="tab-link" data-tab="tab-2">Check Transaction Status</li>
        <li class="tab-link" data-tab="tab-3">Refund</li>
    </ul>
    <!--------------PAYMENT----------------------->
    <div id="tab-1" class="tab-content current">
        <h3>PAYMENT REQUEST SAMPLE</h3>
        <form id="megapayForm" name="megapayForm" method="POST">
            <input type="hidden" name="invoiceNo" value="OrdNo"/>
            <input type="hidden" name="currency" value="VND"/>
            <input type="hidden" name="instmntType" value="1"/>
            <input type="hidden" name="goodsNm" value="T-1000"/>
            <input type="hidden" name="buyerPhone" value="<?php echo $data['buyerPhone'] ?>"/>
            <input type="hidden" name="buyerAddr" value="<?php echo $data['buyerAddr'] ?>"/>
            <input type="hidden" name="buyerCity" value="<?php echo $data['buyerCity'] ?>"/>
            <input type="hidden" name="buyerState" value="hanoi"/>
            <input type="hidden" name="buyerPostCd" value="12950"/>
            <input type="hidden" name="buyerCountry" value="VN"/>
            <input type="hidden" name="fee" value="0"/>
            <input type="hidden" name="vat" value="0"/>
            <input type="hidden" name="notax" value="0"/>

            <!-- Delivery Info -->
            <input type="hidden" name="receiverFirstNm" value="<?php echo $data['receiverFirstNm'] ?>"/>
            <input type="hidden" name="receiverLastNm" value="<?php echo $data['receiverLastNm'] ?>"/>
            <input type="hidden" name="receiverPhone" value="<?php echo $data['receiverPhone'] ?>"/>
            <input type="hidden" name="receiverAddr" value="<?php echo $data['receiverAddr'] ?>"/>
            <input type="hidden" name="receiverCity" value="<?php echo $data['receiverCity'] ?>"/>
            <input type="hidden" name="receiverState" value="hanoi"/>
            <input type="hidden" name="receiverPostCd" value="12950"/>
            <input type="hidden" name="receiverCountry" value="VN"/>
            <input type="hidden" name="description" value="<?php echo $data['description'] ?>"/>
            <input type="hidden" name="paymentExpDt"/>
            <input type="hidden" name="paymentExpTm"/>

            <!------------------------------- Main Value ------------------------------>
            <!-- Call Back URL -->
			<?php $url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
					$url = str_replace('test.php', '', $url);
				
			?>
            <input type="hidden" name="callBackUrl" value="<?php echo $url; ?>/result.php"/>
            <!-- Notify URL -->
            <input type="hidden" name="notiUrl" value="<?php echo $url; ?>/notify.php"/>
            <!-- Merchant ID -->
            <input type="hidden" name="merId" value=''/>
            <!-- Encode Key -->
            
            <!------------------------------------------------------------------------->

            <input type="hidden" name="reqDomain" value="http://localhost:3009"/>
            <input type="hidden" name="reqServerIP" value="127.0.0.1"/>
            <input type="hidden" name="reqClientVer" value=""/>
            <input type="hidden" name="userIP" value="172.16.12.145"/>
            <input type="hidden" name="userSessionID" value="127.0.0.1"/>
            <input type="hidden" name="userAgent" value="chrome"/>
            <input type="hidden" name="userLanguage" value="vn"/>
            <input type="hidden" name="merchantToken" value=""/>
            <input type="hidden" name="payForm" value="PAY"/>
            <input type="hidden" name="version"/>
            <input type="hidden" name="timeStamp" value=""/>
            <input type="hidden" name="mer_temp01" value="temp"/>
            <input type="hidden" name="mer_temp02"/>
            <input type="hidden" name="pg_temp01"/>
            <input type="hidden" name="pg_temp02"/>
            <input type="hidden" name="merTrxId" value="testMerchantTransaction"/>
            <input type="hidden" name="domesticToken"/>
            <input type="hidden" name="userId"/>
            <input type="hidden" name="windowType" value=""/>

            <input type="hidden" name="instmntMon" value="3"/>
            <input type="hidden" name="payType" value="DC"/>
            <input type="hidden" name="goodsAmount" value=""/>
            <input type="hidden" name="userFee" value=""/>
            <input type="hidden" name="buyerLastNm" value="<?php echo $data['buyerLastNm'] ?>"/>
            <input type="hidden" name="buyerFirstNm" value="<?php echo $data['buyerFirstNm'] ?>"/>
            <input type="hidden" name="buyerEmail" value="<?php echo $data['buyerEmail'] ?>"/>
            <div class="row">
                <table>
                    <tr>
                        <td width="25%">Payment Window Color</td>
                        <td width="75%">
                            <input type='radio' id='blue' name='windowColor' value='#ADAFF7' checked/>Blue
                            <input type='radio' id='green' name='windowColor' value='#96CF93'/>Green
                            <input type='radio' id='yellow' name='windowColor' value='#E2E476'/>Yellow
                            <input type='radio' id='purple' name='windowColor' value='#D386ED'/>Purple
                        </td>
                    </tr>
                    <tr>
                        <td>Amount</td>
                        <td>
                            <input type="text" name="amount" id="amount" value="" placeholder="Amount"/>
                        </td>
                    </tr>
                </table>
            </div>
        </form>
        <input type="button" value="Payment Request" onclick="payment();">
    </div>
    <!-------------------------------------------->

    <!----------CHECK TRANSACTION STATUS---------->
    <div id="tab-2" class="tab-content">
        <h3>CHECK TRANSACTION STATUS</h3>
        <form action="http://sanbox.megapay.vn:2710/pg_was/order/trxStatus.do" id="examineForm" name="examineForm"
              method="POST">
            <input type="hidden" name="merchantToken" value="">
            <input type="hidden" name="timeStamp" value="">
            
            <div class="row">
                <table>
                    <tr>
                        <td width="25%">Merchant ID</td>
                        <td width="75%">
                            <input type="text" name="merId" id="merId" placeholder="Merchant ID" value="">
                        </td>
                    </tr>
                    <tr>
                        <td>Merchant Transaction ID</td>
                        <td>
                            <input type="text" name="merTrxId" id="merTrxId" placeholder="Merchant Transaction ID"
                                   value="">
                        </td>
                    </tr>
                </table>
            </div>
        </form>
        <input type="button" value="Check Status" onclick="status();">
    </div>
    <!-------------------------------------------->

    <!--------------REFUND----------------------->
    <div id="tab-3" class="tab-content">
        <h3>REFUND</h3>
        <form action="http://sanbox.megapay.vn:2710/pg_was/cancel/paymentCancel.do" id="cancelForm" name="cancelForm"
              method="POST">
            <input type="hidden" name="merchantToken" value="">
            <input type="hidden" name="cancelServerIp" value="192.168.220.1">
            <input type="hidden" name="cancelUserIp" value="127.0.0.1">
            <input type="hidden" name="cancelUserInfo" value="dangnv">
            <input type="hidden" name="cancelRetryCount" value="0">
            
            <input type="hidden" name="cancelUserId" value="dangnv"/>
            <input type="hidden" name="cancelMsg" value="This is test cancel transaction!!"/>
            <input type="hidden" name="fee" value="0"/>
            <input type="hidden" name="vat" value="0"/>
            <input type="hidden" name="notax" value="0"/>
            <input type="hidden" name="timeStamp" value=""/>
            <input type="hidden" name="payType" value="DC"/>
            <input type="hidden" name="merTrxId" value=""/>
            <input type="hidden" name="cancelPw"
                   value="WfP7i2r/lMbcW6JyL6H6p8jnF7EiTUu3mCf2KDELqieic3JwT99M3TrBqlFjdg5v2oBXED9XcILVSxalBIexhg=="/>
            <div class="row">
                <table>
                    <tr>
                        <td width="25%">Merchant ID</td>
                        <td width="75%">
                            <input type="text" name="merId" id="merIdCancel" placeholder="Merchant ID" value="">
                        </td>
                    </tr>
                   
                    <tr>
                        <td>Trx ID</td>
                        <td>
                            <input type="text" name="trxId" id="trxIdCancel" placeholder="TrxId" value="">
                        </td>
                    </tr>
                    <tr>
                        <td>Amount</td>
                        <td>
                            <input type="text" name="amount" id="amountCancel" placeholder="Amount" value="">
                        </td>
                </table>
            </div>
        </form>
        <input type="button" value="Refund" onclick="refund();">
    </div>
    <!-------------------------------------------->
</div>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="http://sanbox.megapay.vn:2710/pg_was/js/payment/layer/paymentClient.js"></script>
<script type="text/javascript" src="demo.js"></script>
</body>
</html>
