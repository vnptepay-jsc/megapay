<?php
$result = $_GET;
include("Payment.php");
$payment = new Payment();

// Check Token
$check = $payment->checkToken($result);
$error = '';
if (!$check) {
    $error = 'Error';
}
?>

<html>
<head>
    <title>Payment Result</title>
    <meta http-equiv="Content-Type" content="text/html, charset=utf-8">
    <style type="text/css">
        ul.tabs li {
            background: none;
            color: #222;
            display: inline-block;
            padding: 10px 15px;
            cursor: pointer;
        }

        ul.tabs li.current {
            background: #ededed;
            color: #222;
        }

        .tab-content {
            display: none;
            background: #ededed;
            padding: 15px;
        }

        .tab-content.current {
            display: inherit;
        }

        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            border: 1px solid #000000;
            text-align: left;
            padding: 8px;
            font-size: 13px;
        }

    </style>
</head>
<body>
<div style="width: 843px; margin-left: auto; margin-right: auto; margin-top: 4%; text-align: center; border: 1px solid black; padding-top: 1px;">
    <div class="tab-content current">
        <?php if ($error == '') { ?>
            <h3>PAYMENT RESULT: <span style="color: red;"><?php echo $result['resultMsg'] ?></span></h3>
            <div class="row">
                <table>
                    <tr>
                        <td width="25%">trxId</td>
                        <td width="75%">
                            <b><?php echo $result['trxId'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">merId</td>
                        <td width="75%">
                            <b><?php echo $result['merId'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">merTrxId</td>
                        <td width="75%">
                            <b><?php echo $result['merTrxId'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">resultCd</td>
                        <td width="75%">
                            <b><?php echo $result['resultCd'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">resultMsg</td>
                        <td width="75%">
                            <b><?php echo $result['resultMsg'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">invoiceNo</td>
                        <td width="75%">
                            <b><?php echo $result['invoiceNo'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">amount</td>
                        <td width="75%">
                            <b><?php echo $result['amount'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">currency</td>
                        <td width="75%">
                            <b><?php echo $result['currency'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">goodsNm</td>
                        <td width="75%">
                            <b><?php echo $result['goodsNm'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">payType</td>
                        <td width="75%">
                            <b><?php echo $result['payType'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">domesticToken</td>
                        <td width="75%">
                            <b><?php echo $result['domesticToken'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">merchantToken</td>
                        <td width="75%">
                            <b><?php echo $result['merchantToken'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">transDt</td>
                        <td width="75%">
                            <b><?php echo $result['transDt'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">transTm</td>
                        <td width="75%">
                            <b><?php echo $result['transTm'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">buyerFirstNm</td>
                        <td width="75%">
                            <b><?php echo $result['buyerFirstNm'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">buyerLastNm</td>
                        <td width="75%">
                            <b><?php echo $result['buyerLastNm'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">timeStamp</td>
                        <td width="75%">
                            <b><?php echo $result['timeStamp'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">instmntType</td>
                        <td width="75%">
                            <b><?php echo $result['instmntType'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">instmntMon</td>
                        <td width="75%">
                            <b><?php echo $result['instmntMon'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">vaNumber</td>
                        <td width="75%">
                            <b><?php echo $result['vaNumber'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">vaName</td>
                        <td width="75%">
                            <b><?php echo $result['vaName'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">bankId</td>
                        <td width="75%">
                            <b><?php echo $result['bankId'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">bankName</td>
                        <td width="75%">
                            <b><?php echo $result['bankName'] ?></b>
                        </td>
                    </tr>
                    <tr>
                        <td width="25%">cardNo</td>
                        <td width="75%">
                            <b><?php echo $result['cardNo'] ?></b>
                        </td>
                    </tr>
                </table>
            </div>
        <?php } else { ?>
            <h3>PAYMENT RESULT: <span style="color: red;">Invalid Merchant Token</span></h3>
        <?php } ?>
    </div>
</div>
</body>
</html>

