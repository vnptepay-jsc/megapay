<?php
    $post = $_POST;
    include('Payment.php');
    $payment = new Payment();

    $type = $post['type'];
    $encodeKey = $payment::ENCODE_KEY;
    $timeStamp = date('YmdHis');

    if ($type == 1){
        // create merchant token
        $domain = 'http://sanbox.megapay.vn:2710';
        $merId = $payment::MER_ID;
        $merTrxId = 'MERTRXID'.$timeStamp;
        $amount = $post['amount'];

        $str = $timeStamp . $merTrxId . $merId . $amount . $encodeKey;

        // encrypt
        $token = hash('sha256', $str);

        echo json_encode(array('success' => true, 'token'  => $token, 'timeStamp' => $timeStamp, 'merId' => $merId, 'encodeKey' => $encodeKey, 'invoiceNo' => 'OrdNo' . $timeStamp, 'merTrxId' => $merTrxId, 'domain' => $domain));
    } elseif ($type == 2){
		//Inquiry
        // create merchant token
        $merTrxId = $post['merTrxId'];
        $merId = $post['merId'];

        $str = $timeStamp . $merTrxId . $merId . $encodeKey;

        // encrypt
        $token = hash('sha256', $str);

        echo json_encode(array('success' => true, 'token'  => $token, 'timeStamp' => $timeStamp, 'encodeKey' => $encodeKey));
    } else {
		//Refund
        // create merchant token
        $trxId = $post['trxId'];
        $merTrxId = 'MERTRXID'.$timeStamp;
        $merId = $post['merId'];
        $amount = $post['amount'];

        $str = $timeStamp. $merTrxId. $trxId . $merId . $amount . $encodeKey;

        // encrypt
        $token = hash('sha256', $str);

        echo json_encode(array('success' => true, 'token'  => $token, 'timeStamp' => $timeStamp, 'encodeKey' => $encodeKey,'merTrxId' => $merTrxId));
    }
?>